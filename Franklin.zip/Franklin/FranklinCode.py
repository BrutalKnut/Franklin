import os
import json
import requests


def main(req):
    # Parse incoming data from Discord
    try:
        payload = req.get_json()
        user_message = payload.get('content', '')

        if not user_message:
            return {
                'status': 400,
                'body': json.dumps({'error': 'No content received'})
            }

        # Your custom prompt for the chatbot
        prompt = f"Chat with me as if you are a friendly and knowledgeable assistant. {user_message}"

        # OpenAI API request
        api_key = '6EA1ZEaQLrI75CUt0QsOXbRlprHU5orGrAZWEYRrDNbcZpD4QgwvJQQJ99ALAChHRaEXJ3w3AAABACOGNKnC'
        endpoint = 'https://franklinbeast.openai.azure.com/'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {api_key}'
        }
        data = {
            "model": "gpt-3.5-turbo",
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 150
        }

        response = requests.post(endpoint, headers=headers, json=data)
        response_data = response.json()

        # Extract the reply and send it back
        reply = response_data['choices'][0]['message']['content'].strip()

        return {
            'status': 200,
            'body': json.dumps({'reply': reply})
        }
    except Exception as e:
        return {
            'status': 500,
            'body': json.dumps({'error': str(e)})
        }
