import logging
import azure.functions as func

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Processing request...")

    try:
        req_body = req.get_json()
        user_message = req_body.get("message")
        if not user_message:
            return func.HttpResponse(
                "Please provide a 'message' in the request body.",
                status_code=400
            )

        # Generate response (example logic)
        bot_response = f"Hello! You said: {user_message}"

        return func.HttpResponse(bot_response, status_code=200)

    except ValueError:
        return func.HttpResponse(
            "Invalid JSON in request body.",
            status_code=400
        )
